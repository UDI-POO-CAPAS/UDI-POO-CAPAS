package modelo.vo;

public class ClienteVo {
	
	private Integer idCliente;
	private String nombreCliente;
	private Integer edadCliente;
	private String profesionCliente;
	private Integer telefonoCliente;
	
	/**
	 * @return the idCliente
	 */
	public Integer getIdCliente() {
		return idCliente;
	}
	/**
	 * @param idCliente the idCliente to set
	 */
	public void setIdCliente(Integer idCliente) {
		this.idCliente = idCliente;
	}
	/**
	 * @return the nombreCliente
	 */
	public String getNombreCliente() {
		return nombreCliente;
	}
	/**
	 * @param nombreCliente the nombreCliente to set
	 */
	public void setNombreCliente(String nombreCliente) {
		this.nombreCliente = nombreCliente;
	}
	/**
	 * @return the edadCliente
	 */
	public Integer getEdadCliente() {
		return edadCliente;
	}
	/**
	 * @param edadCliente the edadCliente to set
	 */
	public void setEdadCliente(Integer edadCliente) {
		this.edadCliente = edadCliente;
	}
	/**
	 * @return the profesionCliente
	 */
	public String getProfesionCliente() {
		return profesionCliente;
	}
	/**
	 * @param profesionCliente the profesionCliente to set
	 */
	public void setProfesionCliente(String profesionCliente) {
		this.profesionCliente = profesionCliente;
	}
	/**
	 * @return the telefonoCliente
	 */
	public Integer getTelefonoCliente() {
		return telefonoCliente;
	}
	/**
	 * @param telefonoCliente the telefonoCliente to set
	 */
	public void setTelefonoCliente(Integer telefonoCliente) {
		this.telefonoCliente = telefonoCliente;
	}
	

}

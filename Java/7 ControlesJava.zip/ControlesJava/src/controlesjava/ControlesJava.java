/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controlesjava;

/**
 *
 * @author hdueñas
 */
public class ControlesJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ContenedorJava jformulario = new ContenedorJava();
        jformulario.setVisible(true);
    }
}

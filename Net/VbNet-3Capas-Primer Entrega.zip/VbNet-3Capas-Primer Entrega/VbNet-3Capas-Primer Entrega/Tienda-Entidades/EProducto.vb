﻿Public Class EProducto

    Public Property Id() As Integer
    Public Property Descripcion() As String
    Public Property Marca() As String
    Public Property Precio() As Decimal
End Class

﻿Public Class Herencia

    Inherits CapaDatos.Base


End Class

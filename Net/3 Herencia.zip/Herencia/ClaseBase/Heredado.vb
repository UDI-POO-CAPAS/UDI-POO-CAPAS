﻿Public Class Heredado
    Inherits ClaseBase.Base

End Class

﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dato As New CNegocio.CNDato
        Me.txtResultado.Text = dato.llevardato(Me.txtNumero.Text)

    End Sub
End Class
﻿Public Class CNDato
    Dim objllevar As New CDatos.CDSuma
    Public Function llevardato(ByRef x As Integer) As Integer
        Dim xc As Integer
        xc = objllevar.suma(x)

        Return xc
    End Function







End Class

﻿Public Class CDSuma
    Public Function suma(ByRef xn As Integer) As Integer
        Dim Xsuma As Integer
        For i As Integer = 1 To xn
            Xsuma += i
        Next
        Return Xsuma
    End Function
End Class

﻿Public Class vcliente
    Dim idcliente As Integer
    Dim nombres, apellidos, dni, telefono, sexo, direccion, email, observacion As String
    
    Public Property gidcliente
        Get
            Return idcliente
        End Get
        Set(ByVal value)
            idcliente = value
        End Set
    End Property
    Public Property gnombres
        Get
            Return nombres
        End Get
        Set(ByVal value)
            nombres = value
        End Set
    End Property
    Public Property gapellidos
        Get
            Return apellidos

        End Get
        Set(ByVal value)
            apellidos = value
        End Set
    End Property
    Public Property gdni
        Get
            Return dni
        End Get
        Set(ByVal value)
            dni = value
        End Set
    End Property
  
    Public Property gtelefono
        Get
            Return telefono
        End Get
        Set(ByVal value)
            telefono = value
        End Set
    End Property
    Public Property gsexo
        Get
            Return sexo
        End Get
        Set(ByVal value)
            sexo = value
        End Set
    End Property
    Public Property gdireccion
        Get
            Return direccion
        End Get
        Set(ByVal value)
            direccion = value
        End Set
    End Property
    Public Property gemail
        Get
            Return email
        End Get
        Set(ByVal value)
            email = value
        End Set
    End Property

    

    Public Property gobservacion
        Get
            Return observacion
        End Get
        Set(ByVal value)
            observacion = value
        End Set
    End Property


    Public Sub New()

    End Sub

    Public Sub New(ByVal idcliente As Integer, ByVal nombres As String, ByVal apellidos As String, ByVal dni As String, ByVal telefono As String, ByVal sexo As String, ByVal direccion As String, ByVal email As String, ByVal observacion As String)
        gidcliente = idcliente
        gnombres = nombres
        gapellidos = apellidos
        gdni = dni
        gtelefono = telefono
        gsexo = sexo
        gdireccion = direccion
        gemail = email
        gobservacion = observacion
    End Sub
End Class

﻿Public Class Datos
    Public mes As Integer
    Public valor(12) As Integer
    Dim precio As Integer

    Function recibirmes(ByRef m As Integer) As Integer
        Return m
        mes = m
    End Function

    Function recibirprecio(ByRef p As Integer) As Integer
        Return p
        precio = p
    End Function

    Public Function capturar() As Integer

        If (mes >= 1 And mes <= 12) Then
            valor(mes) = precio
        End If
        Return valor(mes)

    End Function





End Class

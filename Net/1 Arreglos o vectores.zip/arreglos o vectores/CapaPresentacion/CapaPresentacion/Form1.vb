﻿Public Class Form1
    Public i As Integer
    Public costo As Integer

    Private Sub btnIngresar_Click(sender As Object, e As EventArgs) Handles btnIngresar.Click
        Dim enviarmes As New CapaDatos.Datos
        Dim enviarprecio As New CapaDatos.Datos
        Dim a As New CapaDatos.Datos
        i = Me.txtMes.Text
        costo = Me.txtValor.Text
        enviarmes.recibirmes(i)
        enviarprecio.recibirprecio(costo)

        Call a.capturar()

        txtMes.Text = ""
        txtValor.Text = ""
        txtMes.Focus()


    End Sub


    Private Sub btnListar_Click(sender As Object, e As EventArgs) Handles btnListar.Click
        Dim a, b As New CapaDatos.Datos
        i = 1
        dgvDatos.Rows.Clear()
        Do While (i <= 12)
            dgvDatos.Rows.Add(i, a.valor(b.mes))
            i = i + 1
        Loop
    End Sub
End Class
